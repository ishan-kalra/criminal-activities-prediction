const cluster = require('cluster');
const A = require('axios');
const express = require('express');
const maxmind = require('maxmind');


process.on('uncaughtException', (err) => {
  console.error(err);
  console.log("Node NOT Exiting...");
});


if(cluster.isMaster) {
  cluster.fork();
  cluster.fork();
  cluster.fork();
} else {
  const app = express();

  const keysToInfer = ['']
    
  const inferKeyProperties = (logs) => {
	  let data = {};
	
	  logs.map((log) => {
	    keysToInfer.map((key) => {
		    if(log.hasOwnProperty(key)) {
		      data[key] = log[key];
		    }
	    })
	  });

	  return data;
  };
    
  app.use(express.static('dist'));

  app.use("/session", (req, res) => {
	  let sessionId = req.url.substring(1).split("=")[1];
	
	  url = `https://logs.juspay.in/logview/exploreSession`;

	  console.info('Fetching session : ', sessionId);
	
	  A({
	    method: 'POST',
	    url: url,
	    data: `sessionId=${sessionId}`
	  }).then((resp) => {
	    console.info('Fetched session  : ', sessionId);
	    res.set("Access-Control-Allow-Origin", "*");
      let logs = resp.data.sessionLogs;
			for(let i=0;i<logs.length;i+=1) {
				if(logs[i].label == 'card_brand'){
					if(logs[i].value.indexOf("+cardBrand+")) {	//Detected card Brand
						var cardBrand = logs[i].value.split("+");			
						resp.data.sessionData.card_brand = cardBrand[3];
					}
					else 
						resp.data.sessionData.card_brand = 'NULL';					
				}
				if(logs[i].label == 'is_auto_submitted'){
					resp.data.sessionData.is_auto_submitted = logs[i].value;
				} 
				if(logs[i].label == 'godel_version'){
					resp.data.sessionData.is_auto_submitted = logs[i].value;
				}
				if(logs[i].label == 'acs_inserted'){
					resp.data.sessionData.acs_inserted =logs[i].value;
				}
				if(logs[i].label == 'sim_operator_name'){
					resp.data.sessionData.sim_operator_name = logs[i].value;
				}
				if(logs[i].label == 'aggregator'){
					resp.data.sessionData.aggregator = logs[i].value;
				}
				if(logs[i].label == 'is_auto_submitting_otp'){
					resp.data.sessionData.is_auto_submitting_otp = logs[i].value;
				}
			}
	    res.json(resp.data);
	  }).catch((err) => {
	    console.error(`Got error when fetching session ${sessionId}`, err);
	    res.status(400);
	  });
  });
  

  const PORT = process.env.PORT || 8081;
  
  app.listen(PORT, () => console.debug('iris log proxy started'));
}
